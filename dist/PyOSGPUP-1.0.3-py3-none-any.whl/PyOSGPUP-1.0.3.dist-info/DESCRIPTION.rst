PyOSGPUP: Python, Open-source
=============================

PuOSGPUP: Python Library that is Open-source created by
Geophysical Engineering, Universitas Pertamina

A python packages for geophysical data processing, modeling, and interpretation.

Teknik Geofisika, Universitas Pertamina
Jl. Teuku Nyak Arief, Simprug, South Jakarta, DKI Jakarta, Indonesia, 12220.
email: metkom.up@gmail.com

