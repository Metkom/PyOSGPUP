from __future__ import print_function

from PyOSGPUP import wavelet
from PyOSGPUP import segypy
from PyOSGPUP import tuning_wedge_acces
from PyOSGPUP import signalpy

__version__ = '1.0.3'
__author__ = 'PyOSGPUP Team'
__license__ = 'MIT'
__copyright__ = '2018, PyOSGPUP Team, https://sites.google.com/site/metkomup/pyosgpup'
